@component('mail::message')
# Welcome to freeCodeGram

This is a community of fellow developers and we love that you have joined us.


All the best,<br>
Victor
@endcomponent
